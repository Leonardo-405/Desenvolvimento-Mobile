package com.example.ac1desenvolvimentomobille;

import android.os.Bundle;
import androidx.appcompat.app.AppCompatActivity;

public class ListaUsuariosActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista_usuarios); // Conectando ao layout XML
    }
}
